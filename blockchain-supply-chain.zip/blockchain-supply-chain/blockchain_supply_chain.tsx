import React, { useState, useEffect } from "react";
import Web3 from "web3"; // or ethers

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertDialog, AlertDialogAction, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Package, Truck, Store, User, Bell, MapPin, Thermometer, Droplets, QrCode, LogOut, Shield, Clock, AlertTriangle, CheckCircle } from 'lucide-react';

// Mock Blockchain Data
const mockBlockchainData = {
  products: [
    {
      id: 'PROD001',
      name: 'Organic Strawberries',
      batch: 'BATCH-2025-001',
      manufacturer: 'FreshFarms Co.',
      manufacturingDate: '2025-10-01',
      expiryDate: '2025-10-10',
      qrCode: 'QR-PROD001',
      currentLocation: { lat: 13.0827, lng: 80.2707, name: 'Chennai Hub' },
      status: 'in_transit',
      blockchainHash: '0x7f9fade1c0d57a7af66ab4ead79fade1c0d57a7af66ab4ead7c2c2eb7b11a91385'
    },
    {
      id: 'PROD002',
      name: 'Fresh Milk (Pasteurized)',
      batch: 'BATCH-2025-002',
      manufacturer: 'DairyPure Ltd.',
      manufacturingDate: '2025-10-04',
      expiryDate: '2025-10-09',
      qrCode: 'QR-PROD002',
      currentLocation: { lat: 13.0500, lng: 80.2500, name: 'Warehouse B' },
      status: 'stored',
      blockchainHash: '0x8a0bdef2d1e68b8bg77bc5fbe8afbef2d1e68b8bg77bc5fbe8d3d3fc8c22ba0496'
    }
  ],
  shipments: [
    {
      id: 'SHIP001',
      productId: 'PROD001',
      transporter: 'ColdChain Express',
      temperature: 4.2,
      humidity: 65,
      threshold: { tempMin: 2, tempMax: 8, humidityMax: 70 },
      route: ['Chennai Hub', 'Coimbatore', 'Bangalore'],
      currentStep: 1,
      alerts: []
    },
    {
      id: 'SHIP002',
      productId: 'PROD002',
      transporter: 'FreezeFast Logistics',
      temperature: 15.8,
      humidity: 78,
      threshold: { tempMin: 2, tempMax: 6, humidityMax: 70 },
      route: ['Warehouse B', 'Distribution Center', 'Retail Store'],
      currentStep: 0,
      alerts: [{ type: 'temperature', message: 'Temperature exceeded threshold', timestamp: Date.now() }]
    }
  ],
  transactions: [
    { id: 'TX001', type: 'Product Created', stakeholder: 'Manufacturer', timestamp: '2025-10-01 08:00', hash: '0x7f9fade...' },
    { id: 'TX002', type: 'Quality Check Passed', stakeholder: 'Manufacturer', timestamp: '2025-10-01 10:30', hash: '0x8a1bcef...' },
    { id: 'TX003', type: 'Shipment Started', stakeholder: 'Transporter', timestamp: '2025-10-02 14:00', hash: '0x9b2cdfg...' },
    { id: 'TX004', type: 'Temperature Alert', stakeholder: 'System', timestamp: '2025-10-03 09:15', hash: '0xac3dehi...' }
  ],
  users: {
    stakeholders: [
      { username: 'owner', password: 'owner123', role: 'Owner', wallet: '0x1234...5678' },
      { username: 'mfg', password: 'mfg123', role: 'Manufacturer', wallet: '0x2345...6789' },
      { username: 'transport', password: 'trans123', role: 'Transporter', wallet: '0x3456...7890' },
      { username: 'retailer', password: 'retail123', role: 'Retailer', wallet: '0x4567...8901' }
    ],
    customers: [
      { username: 'customer1', password: 'cust123', orders: ['PROD001'] },
      { username: 'customer2', password: 'cust456', orders: ['PROD002'] }
    ]
  }
};

// Navbar Component
const Navbar = ({ user, onLogout }) => (
  <nav className="bg-gradient-to-r from-blue-600 to-indigo-700 text-white shadow-lg">
    <div className="container mx-auto px-6 py-4 flex justify-between items-center">
      <div className="flex items-center space-x-3">
        <Package className="w-8 h-8" />
        <h1 className="text-2xl font-bold">BlockChain Supply</h1>
      </div>
      {user && (
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2 bg-white/10 px-4 py-2 rounded-lg">
            <User className="w-5 h-5" />
            <span className="font-medium">{user.username}</span>
            <span className="text-xs bg-white/20 px-2 py-1 rounded">{user.role || 'Customer'}</span>
          </div>
          <button onClick={onLogout} className="bg-red-500 hover:bg-red-600 px-4 py-2 rounded-lg flex items-center space-x-2 transition">
            <LogOut className="w-4 h-4" />
            <span>Logout</span>
          </button>
        </div>
      )}
    </div>
  </nav>
);

// Footer Component
const Footer = () => (
  <footer className="bg-gray-800 text-white py-6 mt-12">
    <div className="container mx-auto px-6 text-center">
      <p className="text-sm">© 2025 BlockChain Supply Chain System. Powered by Edge Computing & IoE.</p>
      <p className="text-xs mt-2 text-gray-400">Securing perishable goods with distributed ledger technology</p>
    </div>
  </footer>
);

// Login Component
const Login = ({ onLogin }) => {
  const [loginType, setLoginType] = useState('stakeholder');
  const [authMethod, setAuthMethod] = useState('credentials');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [wallet, setWallet] = useState('');
  const [error, setError] = useState('');

  const handleLogin = () => {
    setError('');
    
    if (loginType === 'stakeholder') {
      if (authMethod === 'credentials') {
        const user = mockBlockchainData.users.stakeholders.find(
          u => u.username === username && u.password === password
        );
        if (user) {
          onLogin({ ...user, type: 'stakeholder' });
        } else {
          setError('Invalid credentials');
        }
      } else {
        const user = mockBlockchainData.users.stakeholders.find(u => u.wallet === wallet);
        if (user) {
          onLogin({ ...user, type: 'stakeholder' });
        } else {
          setError('Wallet not recognized');
        }
      }
    } else {
      const user = mockBlockchainData.users.customers.find(
        u => u.username === username && u.password === password
      );
      if (user) {
        onLogin({ ...user, type: 'customer' });
      } else {
        setError('Invalid credentials');
      }
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-6">
      <Card className="w-full max-w-md shadow-2xl">
        <CardHeader className="space-y-1 bg-gradient-to-r from-blue-600 to-indigo-700 text-white rounded-t-lg">
          <CardTitle className="text-2xl font-bold text-center flex items-center justify-center space-x-2">
            <Shield className="w-6 h-6" />
            <span>Secure Login</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-6 space-y-4">
          <div className="flex space-x-2">
            <button
              onClick={() => setLoginType('stakeholder')}
              className={`flex-1 py-3 rounded-lg font-medium transition ${
                loginType === 'stakeholder' ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-700'
              }`}
            >
              Stakeholder
            </button>
            <button
              onClick={() => setLoginType('customer')}
              className={`flex-1 py-3 rounded-lg font-medium transition ${
                loginType === 'customer' ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-700'
              }`}
            >
              Customer
            </button>
          </div>

          {loginType === 'stakeholder' && (
            <div className="flex space-x-2">
              <button
                onClick={() => setAuthMethod('credentials')}
                className={`flex-1 py-2 rounded-lg text-sm transition ${
                  authMethod === 'credentials' ? 'bg-indigo-500 text-white' : 'bg-gray-100 text-gray-700'
                }`}
              >
                Username/Password
              </button>
              <button
                onClick={() => setAuthMethod('wallet')}
                className={`flex-1 py-2 rounded-lg text-sm transition ${
                  authMethod === 'wallet' ? 'bg-indigo-500 text-white' : 'bg-gray-100 text-gray-700'
                }`}
              >
                Wallet Address
              </button>
            </div>
          )}

          {authMethod === 'credentials' ? (
            <>
              <input
                type="text"
                placeholder="Username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
              <input
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </>
          ) : (
            <input
              type="text"
              placeholder="Wallet Address (0x...)"
              value={wallet}
              onChange={(e) => setWallet(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          )}

          {error && (
            <Alert className="bg-red-50 border-red-200">
              <AlertDescription className="text-red-800">{error}</AlertDescription>
            </Alert>
          )}

          <button
            onClick={handleLogin}
            className="w-full bg-gradient-to-r from-blue-600 to-indigo-700 text-white py-3 rounded-lg font-semibold hover:shadow-lg transition"
          >
            Login
          </button>

          <div className="text-xs text-gray-500 space-y-1">
            <p><strong>Demo Credentials:</strong></p>
            <p>Stakeholder: owner/owner123, mfg/mfg123</p>
            <p>Customer: customer1/cust123</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

// Alert Modal Component
const AlertModal = ({ alert, onClose, onRelocate, onNotify }) => (
  <AlertDialog open={!!alert} onOpenChange={onClose}>
    <AlertDialogContent>
      <AlertDialogHeader>
        <AlertDialogTitle className="flex items-center space-x-2 text-red-600">
          <AlertTriangle className="w-6 h-6" />
          <span>Threshold Alert</span>
        </AlertDialogTitle>
        <AlertDialogDescription>
          {alert?.message}
          <div className="mt-4 p-3 bg-yellow-50 border border-yellow-200 rounded">
            <p className="text-sm font-medium text-yellow-800">Action Required</p>
            <p className="text-xs text-yellow-700 mt-1">Choose how to handle this situation</p>
          </div>
        </AlertDialogDescription>
      </AlertDialogHeader>
      <AlertDialogFooter className="flex space-x-2">
        <button onClick={onRelocate} className="flex-1 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition">
          Relocate Shipment
        </button>
        <button onClick={onNotify} className="flex-1 bg-orange-600 text-white px-4 py-2 rounded-lg hover:bg-orange-700 transition">
          Notify Stakeholders
        </button>
        <AlertDialogAction onClick={onClose} className="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 transition">
          Close
        </AlertDialogAction>
      </AlertDialogFooter>
    </AlertDialogContent>
  </AlertDialog>
);

// Stakeholder Dashboard
const StakeholderDashboard = ({ user }) => {
  const [shipments, setShipments] = useState(mockBlockchainData.shipments);
  const [selectedAlert, setSelectedAlert] = useState(null);
  const [notification, setNotification] = useState('');

  const handleRelocate = () => {
    setNotification('✅ Relocation request sent to logistics team');
    setSelectedAlert(null);
    setTimeout(() => setNotification(''), 3000);
  };

  const handleNotify = () => {
    setNotification('📧 Alert notifications sent to all stakeholders');
    setSelectedAlert(null);
    setTimeout(() => setNotification(''), 3000);
  };

  const getStatusColor = (status) => {
    const colors = {
      in_transit: 'bg-blue-100 text-blue-800',
      stored: 'bg-green-100 text-green-800',
      delayed: 'bg-yellow-100 text-yellow-800',
      alert: 'bg-red-100 text-red-800'
    };
    return colors[status] || 'bg-gray-100 text-gray-800';
  };

  const activeAlerts = shipments.filter(s => s.alerts.length > 0);

  return (
    <div className="container mx-auto px-6 py-8">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-gray-800 mb-2">Welcome, {user.role}</h2>
        <p className="text-gray-600">Monitor and manage your supply chain operations</p>
      </div>

      {notification && (
        <Alert className="mb-6 bg-green-50 border-green-200">
          <AlertDescription className="text-green-800">{notification}</AlertDescription>
        </Alert>
      )}

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white">
          <CardContent className="pt-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm opacity-90">Active Shipments</p>
                <p className="text-3xl font-bold mt-2">{shipments.length}</p>
              </div>
              <Truck className="w-10 h-10 opacity-80" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-red-500 to-red-600 text-white">
          <CardContent className="pt-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm opacity-90">Active Alerts</p>
                <p className="text-3xl font-bold mt-2">{activeAlerts.length}</p>
              </div>
              <Bell className="w-10 h-10 opacity-80" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white">
          <CardContent className="pt-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm opacity-90">Products Tracked</p>
                <p className="text-3xl font-bold mt-2">{mockBlockchainData.products.length}</p>
              </div>
              <Package className="w-10 h-10 opacity-80" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white">
          <CardContent className="pt-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm opacity-90">Transactions</p>
                <p className="text-3xl font-bold mt-2">{mockBlockchainData.transactions.length}</p>
              </div>
              <Shield className="w-10 h-10 opacity-80" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Active Alerts */}
      {activeAlerts.length > 0 && (
        <Card className="mb-8 border-red-200 bg-red-50">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 text-red-700">
              <AlertTriangle className="w-5 h-5" />
              <span>Critical Alerts</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {activeAlerts.map(shipment => (
              <div key={shipment.id} className="bg-white p-4 rounded-lg mb-2 last:mb-0">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="font-semibold text-gray-800">Shipment: {shipment.id}</p>
                    <p className="text-sm text-red-600 mt-1">{shipment.alerts[0].message}</p>
                    <p className="text-xs text-gray-500 mt-1">Temperature: {shipment.temperature}°C (Max: {shipment.threshold.tempMax}°C)</p>
                  </div>
                  <button
                    onClick={() => setSelectedAlert(shipment.alerts[0])}
                    className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition text-sm"
                  >
                    Take Action
                  </button>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Live Monitoring */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Thermometer className="w-5 h-5" />
            <span>Live Shipment Monitoring</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {shipments.map(shipment => {
              const product = mockBlockchainData.products.find(p => p.id === shipment.productId);
              const tempStatus = shipment.temperature > shipment.threshold.tempMax ? 'text-red-600' : 'text-green-600';
              const humidityStatus = shipment.humidity > shipment.threshold.humidityMax ? 'text-red-600' : 'text-green-600';

              return (
                <div key={shipment.id} className="border rounded-lg p-4 hover:shadow-md transition">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <h3 className="font-semibold text-lg">{product?.name}</h3>
                      <p className="text-sm text-gray-600">Batch: {product?.batch}</p>
                    </div>
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(product?.status)}`}>
                      {product?.status.replace('_', ' ').toUpperCase()}
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-4 mb-3">
                    <div className="bg-blue-50 p-3 rounded-lg">
                      <div className="flex items-center space-x-2 mb-1">
                        <Thermometer className="w-4 h-4 text-blue-600" />
                        <span className="text-xs font-medium text-gray-600">Temperature</span>
                      </div>
                      <p className={`text-xl font-bold ${tempStatus}`}>{shipment.temperature}°C</p>
                      <p className="text-xs text-gray-500">Range: {shipment.threshold.tempMin}-{shipment.threshold.tempMax}°C</p>
                    </div>

                    <div className="bg-cyan-50 p-3 rounded-lg">
                      <div className="flex items-center space-x-2 mb-1">
                        <Droplets className="w-4 h-4 text-cyan-600" />
                        <span className="text-xs font-medium text-gray-600">Humidity</span>
                      </div>
                      <p className={`text-xl font-bold ${humidityStatus}`}>{shipment.humidity}%</p>
                      <p className="text-xs text-gray-500">Max: {shipment.threshold.humidityMax}%</p>
                    </div>

                    <div className="bg-green-50 p-3 rounded-lg">
                      <div className="flex items-center space-x-2 mb-1">
                        <MapPin className="w-4 h-4 text-green-600" />
                        <span className="text-xs font-medium text-gray-600">Location</span>
                      </div>
                      <p className="text-sm font-bold text-gray-800">{product?.currentLocation.name}</p>
                      <p className="text-xs text-gray-500">{product?.currentLocation.lat.toFixed(4)}, {product?.currentLocation.lng.toFixed(4)}</p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2 text-sm text-gray-600">
                    <Clock className="w-4 h-4" />
                    <span>Route: {shipment.route.join(' → ')}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Blockchain Transactions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Shield className="w-5 h-5" />
            <span>Recent Blockchain Transactions</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {mockBlockchainData.transactions.map(tx => (
              <div key={tx.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition">
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <div>
                    <p className="font-medium text-sm">{tx.type}</p>
                    <p className="text-xs text-gray-500">{tx.stakeholder} • {tx.timestamp}</p>
                  </div>
                </div>
                <code className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">{tx.hash}</code>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <AlertModal
        alert={selectedAlert}
        onClose={() => setSelectedAlert(null)}
        onRelocate={handleRelocate}
        onNotify={handleNotify}
      />
    </div>
  );
};

// Customer Dashboard
const CustomerDashboard = ({ user }) => {
  const [scannedProduct, setScannedProduct] = useState(null);
  const [scanning, setScanning] = useState(false);

  const handleScan = () => {
    setScanning(true);
    setTimeout(() => {
      const product = mockBlockchainData.products[0];
      setScannedProduct(product);
      setScanning(false);
    }, 1500);
  };

  return (
    <div className="container mx-auto px-6 py-8">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-gray-800 mb-2">Customer Portal</h2>
        <p className="text-gray-600">Track your orders and verify product authenticity</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* QR Scanner */}
        <Card className="h-fit">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <QrCode className="w-5 h-5" />
              <span>Scan Product QR Code</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center">
              <div className="bg-gradient-to-br from-blue-100 to-indigo-100 p-12 rounded-lg mb-4">
                {scanning ? (
                  <div className="animate-pulse">
                    <QrCode className="w-24 h-24 mx-auto text-blue-600" />
                    <p className="text-sm text-gray-600 mt-4">Scanning...</p>
                  </div>
                ) : (
                  <QrCode className="w-24 h-24 mx-auto text-gray-400" />
                )}
              </div>
              <button
                onClick={handleScan}
                disabled={scanning}
                className="w-full bg-gradient-to-r from-blue-600 to-indigo-700 text-white py-3 rounded-lg font-semibold hover:shadow-lg transition disabled:opacity-50"
              >
                {scanning ? 'Scanning...' : 'Scan QR Code'}
              </button>
              <p className="text-xs text-gray-500 mt-2">Click to simulate QR code scan</p>
            </div>
          </CardContent>
        </Card>

        {/* Product Details */}
        {scannedProduct && (
          <Card className="h-fit">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Package className="w-5 h-5" />
                <span>Product Details</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="text-2xl font-bold text-gray-800 mb-1">{scannedProduct.name}</h3>
                <p className="text-sm text-gray-600">Batch: {scannedProduct.batch}</p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-blue-50 p-3 rounded-lg">
                  <p className="text-xs text-gray-600 mb-1">Manufacturer</p>
                  <p className="font-semibold text-sm">{scannedProduct.manufacturer}</p>
                </div>
                <div className="bg-green-50 p-3 rounded-lg">
                  <p className="text-xs text-gray-600 mb-1">Status</p>
                  <p className="font-semibold text-sm text-green-700">{scannedProduct.status.replace('_', ' ').toUpperCase()}</p>
                </div>
                <div className="bg-yellow-50 p-3 rounded-lg">
                  <p className="text-xs text-gray-600 mb-1">Mfg Date</p>
                  <p className="font-semibold text-sm">{scannedProduct.manufacturingDate}</p>
                </div>
                <div className="bg-red-50 p-3 rounded-lg">
                  <p className="text-xs text-gray-600 mb-1">Expiry Date</p>
                  <p className="font-semibold text-sm">{scannedProduct.expiryDate}</p>
                </div>
              </div>

              <div className="bg-gradient-to-r from-green-50 to-emerald-50 p-4 rounded-lg border border-green-200">
                <div className="flex items-center space-x-2 mb-2">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  <span className="font-semibold text-green-800">Blockchain Verified</span>
                </div>
                <p className="text-xs text-green-700">This product is authentic and tracked on blockchain</p>
                <code className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded mt-2 block break-all">
                  {scannedProduct.blockchainHash}
                </code>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="flex items-center space-x-2 mb-3">
                  <MapPin className="w-5 h-5 text-blue-600" />
                  <span className="font-semibold">Live GPS Tracking</span>
                </div>
                <div className="bg-white p-3 rounded border">
                  <p className="text-sm mb-2">
                    <strong>Current Location:</strong> {scannedProduct.currentLocation.name}
                  </p>
                  <p className="text-xs text-gray-600">
                    Coordinates: {scannedProduct.currentLocation.lat.toFixed(4)}°N, {scannedProduct.currentLocation.lng.toFixed(4)}°E
                  </p>
                  <div className="mt-3 bg-blue-100 h-32 rounded flex items-center justify-center">
                    <MapPin className="w-12 h-12 text-blue-600 animate-pulse" />
                  </div>
                  <p className="text-xs text-center text-gray-500 mt-2">Live tracking active</p>
                </div>
              </div>

              <div className="bg-indigo-50 p-4 rounded-lg">
                <h4 className="font-semibold text-sm mb-3 flex items-center space-x-2">
                  <Truck className="w-4 h-4" />
                  <span>Product Journey</span>
                </h4>
                <div className="space-y-2">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center text-white text-xs font-bold">✓</div>
                    <div className="flex-1">
                      <p className="text-xs font-medium">Manufacturing Complete</p>
                      <p className="text-xs text-gray-600">{scannedProduct.manufacturer}</p>
                    </div>
                  </div>
                  <div className="ml-4 border-l-2 border-green-300 h-4"></div>
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center text-white text-xs font-bold">✓</div>
                    <div className="flex-1">
                      <p className="text-xs font-medium">Quality Check Passed</p>
                      <p className="text-xs text-gray-600">Certified</p>
                    </div>
                  </div>
                  <div className="ml-4 border-l-2 border-blue-300 h-4"></div>
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white text-xs font-bold">→</div>
                    <div className="flex-1">
                      <p className="text-xs font-medium">In Transit</p>
                      <p className="text-xs text-gray-600">{scannedProduct.currentLocation.name}</p>
                    </div>
                  </div>
                  <div className="ml-4 border-l-2 border-gray-300 h-4"></div>
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center text-white text-xs font-bold">○</div>
                    <div className="flex-1">
                      <p className="text-xs font-medium text-gray-500">Awaiting Delivery</p>
                      <p className="text-xs text-gray-400">Pending</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* My Orders */}
      <Card className="mt-8">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Package className="w-5 h-5" />
            <span>My Orders</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {user.orders.map(orderId => {
              const product = mockBlockchainData.products.find(p => p.id === orderId);
              return product ? (
                <div key={product.id} className="border rounded-lg p-4 hover:shadow-md transition">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-semibold">{product.name}</h3>
                      <p className="text-sm text-gray-600">Order ID: {product.id}</p>
                      <p className="text-xs text-gray-500 mt-1">Expected delivery: {product.expiryDate}</p>
                    </div>
                    <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-xs font-medium">
                      {product.status.replace('_', ' ').toUpperCase()}
                    </span>
                  </div>
                  <button
                    onClick={() => setScannedProduct(product)}
                    className="mt-3 text-sm text-blue-600 hover:text-blue-800 font-medium"
                  >
                    View Details →
                  </button>
                </div>
              ) : null;
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

// Main App
const App = () => {
  const [user, setUser] = useState(null);

  const handleLogin = (userData) => {
    setUser(userData);
  };

  const handleLogout = () => {
    setUser(null);
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {user ? (
        <>
          <Navbar user={user} onLogout={handleLogout} />
          {user.type === 'stakeholder' ? (
            <StakeholderDashboard user={user} />
          ) : (
            <CustomerDashboard user={user} />
          )}
          <Footer />
        </>
      ) : (
        <Login onLogin={handleLogin} />
      )}
    </div>
  );
};

export default App;