import { User, Product, Shipment, IoTReading, Alert, BlockchainTransaction, ShipmentHistory } from '../types';

export const mockUsers: User[] = [
  {
    id: 'u1',
    email: 'owner@supply.com',
    role: 'owner',
    name: 'John Smith',
    walletAddress: '0x1234...5678',
    companyName: 'Supply Chain Corp'
  },
  {
    id: 'u2',
    email: 'manufacturer@pharma.com',
    role: 'manufacturer',
    name: 'Sarah Johnson',
    walletAddress: '0x2345...6789',
    companyName: 'PharmaLife Inc'
  },
  {
    id: 'u3',
    email: 'transport@logistics.com',
    role: 'transporter',
    name: 'Mike Wilson',
    walletAddress: '0x3456...7890',
    companyName: 'FastTrack Logistics'
  },
  {
    id: 'u4',
    email: 'retailer@store.com',
    role: 'retailer',
    name: 'Emma Davis',
    walletAddress: '0x4567...8901',
    companyName: 'HealthMart Stores'
  }
];

export const mockProducts: Product[] = [
  {
    id: 'p1',
    name: 'Insulin Vials (10ml)',
    description: 'Temperature-sensitive insulin medication requiring cold chain',
    category: 'Pharmaceutical',
    origin: 'Boston, MA, USA',
    manufacturerId: 'u2',
    batchNumber: 'INS-2025-001',
    manufactureDate: '2025-01-15T08:00:00Z',
    expiryDate: '2025-07-15T08:00:00Z',
    optimalTempMin: 2,
    optimalTempMax: 8,
    optimalHumidityMin: 40,
    optimalHumidityMax: 60
  },
  {
    id: 'p2',
    name: 'Fresh Atlantic Salmon',
    description: 'Premium grade fresh salmon fillets',
    category: 'Seafood',
    origin: 'Portland, ME, USA',
    manufacturerId: 'u2',
    batchNumber: 'SAL-2025-042',
    manufactureDate: '2025-10-03T06:00:00Z',
    expiryDate: '2025-10-10T06:00:00Z',
    optimalTempMin: -2,
    optimalTempMax: 4,
    optimalHumidityMin: 80,
    optimalHumidityMax: 95
  },
  {
    id: 'p3',
    name: 'COVID-19 Vaccine (Pfizer)',
    description: 'mRNA vaccine requiring ultra-cold storage',
    category: 'Vaccine',
    origin: 'Kalamazoo, MI, USA',
    manufacturerId: 'u2',
    batchNumber: 'VAC-2025-789',
    manufactureDate: '2025-09-20T10:00:00Z',
    expiryDate: '2026-03-20T10:00:00Z',
    optimalTempMin: -80,
    optimalTempMax: -60,
    optimalHumidityMin: 30,
    optimalHumidityMax: 50
  }
];

export const mockShipments: Shipment[] = [
  {
    id: 's1',
    productId: 'p1',
    currentOwnerId: 'u3',
    status: 'alert',
    origin: 'Boston, MA',
    destination: 'New York, NY',
    currentLocation: 'Hartford, CT',
    qrCode: 'QR-INS-001',
    createdAt: '2025-10-04T08:00:00Z',
    updatedAt: '2025-10-05T10:30:00Z'
  },
  {
    id: 's2',
    productId: 'p2',
    currentOwnerId: 'u3',
    status: 'in_transit',
    origin: 'Portland, ME',
    destination: 'Boston, MA',
    currentLocation: 'Portsmouth, NH',
    qrCode: 'QR-SAL-042',
    createdAt: '2025-10-05T06:00:00Z',
    updatedAt: '2025-10-05T11:15:00Z'
  },
  {
    id: 's3',
    productId: 'p3',
    currentOwnerId: 'u4',
    status: 'delivered',
    origin: 'Kalamazoo, MI',
    destination: 'Chicago, IL',
    currentLocation: 'Chicago, IL',
    qrCode: 'QR-VAC-789',
    createdAt: '2025-10-01T09:00:00Z',
    updatedAt: '2025-10-03T14:00:00Z'
  }
];

export const mockIoTReadings: IoTReading[] = [
  {
    id: 'r1',
    shipmentId: 's1',
    temperature: 12.5,
    humidity: 55,
    latitude: 41.7658,
    longitude: -72.6734,
    recordedAt: '2025-10-05T11:45:00Z'
  },
  {
    id: 'r2',
    shipmentId: 's2',
    temperature: 2.8,
    humidity: 88,
    latitude: 43.0718,
    longitude: -70.7626,
    recordedAt: '2025-10-05T11:45:00Z'
  },
  {
    id: 'r3',
    shipmentId: 's3',
    temperature: -72,
    humidity: 42,
    latitude: 41.8781,
    longitude: -87.6298,
    recordedAt: '2025-10-05T11:45:00Z'
  }
];

export const mockAlerts: Alert[] = [
  {
    id: 'a1',
    shipmentId: 's1',
    alertType: 'temperature',
    severity: 'critical',
    message: 'Temperature exceeded safe range: 12.5°C (max: 8°C)',
    isResolved: false,
    createdAt: '2025-10-05T10:30:00Z'
  }
];

export const mockBlockchainTransactions: BlockchainTransaction[] = [
  {
    id: 't1',
    shipmentId: 's1',
    transactionHash: '0xabc123def456...',
    blockNumber: 15678901,
    transactionType: 'transfer',
    fromAddress: '0x2345...6789',
    toAddress: '0x3456...7890',
    data: { action: 'shipment_created', timestamp: '2025-10-04T08:00:00Z' },
    timestamp: '2025-10-04T08:00:00Z'
  },
  {
    id: 't2',
    shipmentId: 's1',
    transactionHash: '0xdef456ghi789...',
    blockNumber: 15678945,
    transactionType: 'alert',
    fromAddress: '0x3456...7890',
    data: { alert_type: 'temperature', severity: 'critical', value: 12.5 },
    timestamp: '2025-10-05T10:30:00Z'
  },
  {
    id: 't3',
    shipmentId: 's2',
    transactionHash: '0xghi789jkl012...',
    blockNumber: 15679012,
    transactionType: 'transfer',
    fromAddress: '0x2345...6789',
    toAddress: '0x3456...7890',
    data: { action: 'shipment_created', timestamp: '2025-10-05T06:00:00Z' },
    timestamp: '2025-10-05T06:00:00Z'
  },
  {
    id: 't4',
    shipmentId: 's3',
    transactionHash: '0xjkl012mno345...',
    blockNumber: 15677890,
    transactionType: 'transfer',
    fromAddress: '0x2345...6789',
    toAddress: '0x4567...8901',
    data: { action: 'delivered', timestamp: '2025-10-03T14:00:00Z' },
    timestamp: '2025-10-03T14:00:00Z'
  }
];

export const mockShipmentHistory: ShipmentHistory[] = [
  {
    id: 'h1',
    shipmentId: 's1',
    stakeholderId: 'u2',
    action: 'created',
    description: 'Shipment created by PharmaLife Inc',
    location: 'Boston, MA',
    createdAt: '2025-10-04T08:00:00Z'
  },
  {
    id: 'h2',
    shipmentId: 's1',
    stakeholderId: 'u3',
    action: 'transferred',
    description: 'Shipment picked up by FastTrack Logistics',
    location: 'Boston, MA',
    createdAt: '2025-10-04T09:30:00Z'
  },
  {
    id: 'h3',
    shipmentId: 's1',
    stakeholderId: 'u3',
    action: 'alerted',
    description: 'Critical temperature alert triggered',
    location: 'Hartford, CT',
    createdAt: '2025-10-05T10:30:00Z'
  }
];
