import { BlockchainTransaction } from '../types';

export class BlockchainService {
  private static instance: BlockchainService;
  private blockNumber: number = 15679100;

  private constructor() {}

  static getInstance(): BlockchainService {
    if (!BlockchainService.instance) {
      BlockchainService.instance = new BlockchainService();
    }
    return BlockchainService.instance;
  }

  generateTransactionHash(): string {
    const chars = '0123456789abcdef';
    let hash = '0x';
    for (let i = 0; i < 64; i++) {
      hash += chars[Math.floor(Math.random() * chars.length)];
    }
    return hash;
  }

  async createTransaction(
    shipmentId: string,
    transactionType: 'transfer' | 'alert' | 'condition_update',
    fromAddress: string,
    toAddress: string | undefined,
    data: Record<string, unknown>
  ): Promise<BlockchainTransaction> {
    await new Promise(resolve => setTimeout(resolve, 500));

    this.blockNumber += 1;

    const transaction: BlockchainTransaction = {
      id: `t${Date.now()}`,
      shipmentId,
      transactionHash: this.generateTransactionHash(),
      blockNumber: this.blockNumber,
      transactionType,
      fromAddress,
      toAddress,
      data,
      timestamp: new Date().toISOString()
    };

    return transaction;
  }

  async verifyTransaction(transactionHash: string): Promise<boolean> {
    await new Promise(resolve => setTimeout(resolve, 300));
    return transactionHash.startsWith('0x') && transactionHash.length === 66;
  }

  async getBlockchainStatus(): Promise<{ connected: boolean; latestBlock: number; networkId: string }> {
    return {
      connected: true,
      latestBlock: this.blockNumber,
      networkId: 'SupplyChain-TestNet'
    };
  }
}

export const blockchainService = BlockchainService.getInstance();
