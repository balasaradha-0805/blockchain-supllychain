import { IoTReading, Product } from '../types';

export class IoTService {
  private static instance: IoTService;
  private intervals: Map<string, NodeJS.Timeout> = new Map();

  private constructor() {}

  static getInstance(): IoTService {
    if (!IoTService.instance) {
      IoTService.instance = new IoTService();
    }
    return IoTService.instance;
  }

  generateReading(
    shipmentId: string,
    product: Product,
    baseTemp: number,
    baseHumidity: number,
    latitude?: number,
    longitude?: number
  ): IoTReading {
    const tempVariation = (Math.random() - 0.5) * 3;
    const humidityVariation = (Math.random() - 0.5) * 5;

    return {
      id: `r${Date.now()}`,
      shipmentId,
      temperature: parseFloat((baseTemp + tempVariation).toFixed(1)),
      humidity: parseFloat((baseHumidity + humidityVariation).toFixed(1)),
      latitude: latitude ? latitude + (Math.random() - 0.5) * 0.01 : undefined,
      longitude: longitude ? longitude + (Math.random() - 0.5) * 0.01 : undefined,
      recordedAt: new Date().toISOString()
    };
  }

  startMonitoring(
    shipmentId: string,
    product: Product,
    baseTemp: number,
    baseHumidity: number,
    latitude: number | undefined,
    longitude: number | undefined,
    onReading: (reading: IoTReading) => void,
    intervalMs: number = 5000
  ): void {
    if (this.intervals.has(shipmentId)) {
      this.stopMonitoring(shipmentId);
    }

    const interval = setInterval(() => {
      const reading = this.generateReading(
        shipmentId,
        product,
        baseTemp,
        baseHumidity,
        latitude,
        longitude
      );
      onReading(reading);
    }, intervalMs);

    this.intervals.set(shipmentId, interval);
  }

  stopMonitoring(shipmentId: string): void {
    const interval = this.intervals.get(shipmentId);
    if (interval) {
      clearInterval(interval);
      this.intervals.delete(shipmentId);
    }
  }

  stopAllMonitoring(): void {
    this.intervals.forEach((interval) => clearInterval(interval));
    this.intervals.clear();
  }
}

export const iotService = IoTService.getInstance();
