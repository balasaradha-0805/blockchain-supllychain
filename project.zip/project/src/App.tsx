import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { LoginPage } from './components/LoginPage';
import { Dashboard } from './components/Dashboard';
import { CustomerTracking } from './components/CustomerTracking';

const AppContent: React.FC = () => {
  const { isAuthenticated } = useAuth();
  const [showCustomerTracking, setShowCustomerTracking] = useState(false);

  if (showCustomerTracking) {
    return <CustomerTracking onBack={() => setShowCustomerTracking(false)} />;
  }

  if (isAuthenticated) {
    return <Dashboard />;
  }

  return <LoginPage onCustomerAccess={() => setShowCustomerTracking(true)} />;
};

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
