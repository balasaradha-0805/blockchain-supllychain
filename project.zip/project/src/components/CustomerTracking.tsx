import React, { useState } from 'react';
import { ShipmentWithDetails } from '../types';
import { mockShipments, mockProducts, mockUsers, mockIoTReadings, mockAlerts, mockBlockchainTransactions, mockShipmentHistory } from '../services/mockData';
import { Package, MapPin, Thermometer, Droplets, Calendar, Factory, ShieldCheck, ArrowLeft, Search } from 'lucide-react';

interface CustomerTrackingProps {
  onBack: () => void;
}

export const CustomerTracking: React.FC<CustomerTrackingProps> = ({ onBack }) => {
  const [qrCode, setQrCode] = useState('');
  const [shipment, setShipment] = useState<ShipmentWithDetails | null>(null);
  const [notFound, setNotFound] = useState(false);

  const handleSearch = () => {
    const foundShipment = mockShipments.find(s => s.qrCode === qrCode);

    if (foundShipment) {
      const product = mockProducts.find(p => p.id === foundShipment.productId)!;
      const currentOwner = mockUsers.find(u => u.id === foundShipment.currentOwnerId)!;
      const latestReading = mockIoTReadings.find(r => r.shipmentId === foundShipment.id);
      const shipmentAlerts = mockAlerts.filter(a => a.shipmentId === foundShipment.id);
      const transactions = mockBlockchainTransactions.filter(t => t.shipmentId === foundShipment.id);
      const history = mockShipmentHistory.filter(h => h.shipmentId === foundShipment.id);

      setShipment({
        ...foundShipment,
        product,
        currentOwner,
        latestReading,
        alerts: shipmentAlerts,
        transactions,
        history
      });
      setNotFound(false);
    } else {
      setShipment(null);
      setNotFound(true);
    }
  };

  const isAuthentic = shipment && shipment.transactions.length > 0;
  const isTempSafe = shipment?.latestReading ?
    shipment.latestReading.temperature >= shipment.product.optimalTempMin &&
    shipment.latestReading.temperature <= shipment.product.optimalTempMax : true;

  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-50 via-white to-violet-50">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-violet-600 hover:text-violet-700 mb-6 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          Back to Login
        </button>

        <div className="bg-white rounded-3xl shadow-2xl border border-violet-100 overflow-hidden">
          <div className="bg-gradient-to-r from-violet-600 to-violet-700 p-8 text-white">
            <div className="flex items-center gap-3 mb-4">
              <Package className="w-10 h-10" />
              <div>
                <h1 className="text-3xl font-bold">Track Your Product</h1>
                <p className="text-violet-100">Verify authenticity and monitor conditions</p>
              </div>
            </div>
          </div>

          <div className="p-8">
            <div className="mb-8">
              <label className="block text-sm font-medium text-gray-700 mb-3">
                Enter QR Code or Batch Number
              </label>
              <div className="flex gap-3">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    value={qrCode}
                    onChange={(e) => {
                      setQrCode(e.target.value);
                      setNotFound(false);
                    }}
                    onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                    placeholder="e.g., QR-INS-001"
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-violet-500 focus:border-transparent outline-none transition-all"
                  />
                </div>
                <button
                  onClick={handleSearch}
                  className="bg-gradient-to-r from-violet-600 to-violet-700 text-white px-8 py-3 rounded-lg font-medium hover:from-violet-700 hover:to-violet-800 transition-all shadow-lg hover:shadow-xl"
                >
                  Track
                </button>
              </div>

              {notFound && (
                <div className="mt-3 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
                  Product not found. Please check the QR code and try again.
                </div>
              )}

              <div className="mt-4 p-4 bg-violet-50 border border-violet-100 rounded-lg">
                <p className="text-sm text-violet-900 font-medium mb-2">Try these sample QR codes:</p>
                <div className="flex flex-wrap gap-2">
                  <button
                    onClick={() => setQrCode('QR-INS-001')}
                    className="px-3 py-1 bg-white border border-violet-200 rounded-md text-sm text-violet-700 hover:bg-violet-100 transition-colors"
                  >
                    QR-INS-001
                  </button>
                  <button
                    onClick={() => setQrCode('QR-SAL-042')}
                    className="px-3 py-1 bg-white border border-violet-200 rounded-md text-sm text-violet-700 hover:bg-violet-100 transition-colors"
                  >
                    QR-SAL-042
                  </button>
                  <button
                    onClick={() => setQrCode('QR-VAC-789')}
                    className="px-3 py-1 bg-white border border-violet-200 rounded-md text-sm text-violet-700 hover:bg-violet-100 transition-colors"
                  >
                    QR-VAC-789
                  </button>
                </div>
              </div>
            </div>

            {shipment && (
              <div className="space-y-6 animate-fadeIn">
                <div className="flex items-center gap-3 p-4 bg-green-50 border border-green-200 rounded-lg">
                  <ShieldCheck className="w-6 h-6 text-green-600" />
                  <div>
                    <p className="font-medium text-green-900">Blockchain Verified</p>
                    <p className="text-sm text-green-700">
                      {shipment.transactions.length} transactions recorded
                    </p>
                  </div>
                </div>

                <div className="bg-gradient-to-br from-violet-50 to-white p-6 rounded-xl border border-violet-100">
                  <h2 className="text-2xl font-bold text-gray-900 mb-4">{shipment.product.name}</h2>
                  <p className="text-gray-600 mb-4">{shipment.product.description}</p>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="flex items-center gap-3">
                      <Factory className="w-5 h-5 text-violet-600" />
                      <div>
                        <p className="text-xs text-gray-500">Origin</p>
                        <p className="text-sm font-medium text-gray-900">{shipment.product.origin}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <Package className="w-5 h-5 text-violet-600" />
                      <div>
                        <p className="text-xs text-gray-500">Batch Number</p>
                        <p className="text-sm font-medium text-gray-900">{shipment.product.batchNumber}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <Calendar className="w-5 h-5 text-violet-600" />
                      <div>
                        <p className="text-xs text-gray-500">Manufactured</p>
                        <p className="text-sm font-medium text-gray-900">
                          {new Date(shipment.product.manufactureDate).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <Calendar className="w-5 h-5 text-violet-600" />
                      <div>
                        <p className="text-xs text-gray-500">Expires</p>
                        <p className="text-sm font-medium text-gray-900">
                          {new Date(shipment.product.expiryDate).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-white p-6 rounded-xl border border-gray-200">
                  <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
                    <MapPin className="w-5 h-5 text-violet-600" />
                    Current Location
                  </h3>
                  <p className="text-gray-900 font-medium mb-2">{shipment.currentLocation}</p>
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <span>Status:</span>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      shipment.status === 'delivered' ? 'bg-green-100 text-green-700' :
                      shipment.status === 'in_transit' ? 'bg-blue-100 text-blue-700' :
                      'bg-red-100 text-red-700'
                    }`}>
                      {shipment.status.replace('_', ' ').toUpperCase()}
                    </span>
                  </div>
                </div>

                {shipment.latestReading && (
                  <div className="bg-white p-6 rounded-xl border border-gray-200">
                    <h3 className="text-lg font-bold text-gray-900 mb-4">Current Conditions</h3>
                    <div className="grid grid-cols-2 gap-6">
                      <div className="flex items-center gap-4">
                        <div className={`p-3 rounded-lg ${isTempSafe ? 'bg-green-100' : 'bg-red-100'}`}>
                          <Thermometer className={`w-6 h-6 ${isTempSafe ? 'text-green-600' : 'text-red-600'}`} />
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Temperature</p>
                          <p className={`text-2xl font-bold ${isTempSafe ? 'text-gray-900' : 'text-red-600'}`}>
                            {shipment.latestReading.temperature}°C
                          </p>
                          <p className="text-xs text-gray-500 mt-1">
                            Safe range: {shipment.product.optimalTempMin}°C - {shipment.product.optimalTempMax}°C
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-4">
                        <div className="p-3 rounded-lg bg-blue-100">
                          <Droplets className="w-6 h-6 text-blue-600" />
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Humidity</p>
                          <p className="text-2xl font-bold text-gray-900">
                            {shipment.latestReading.humidity}%
                          </p>
                          <p className="text-xs text-gray-500 mt-1">
                            Safe range: {shipment.product.optimalHumidityMin}% - {shipment.product.optimalHumidityMax}%
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                <div className="bg-white p-6 rounded-xl border border-gray-200">
                  <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
                    <ShieldCheck className="w-5 h-5 text-violet-600" />
                    Blockchain Verification
                  </h3>
                  <div className="space-y-3">
                    {shipment.transactions.slice(0, 3).map(tx => (
                      <div key={tx.id} className="p-4 bg-violet-50 rounded-lg border border-violet-100">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm font-medium text-violet-900">
                            {tx.transactionType.toUpperCase()}
                          </span>
                          <span className="text-xs text-violet-700">Block #{tx.blockNumber}</span>
                        </div>
                        <p className="text-xs text-violet-600 font-mono truncate mb-2">
                          {tx.transactionHash}
                        </p>
                        <p className="text-xs text-gray-600">
                          {new Date(tx.timestamp).toLocaleString()}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-white p-6 rounded-xl border border-gray-200">
                  <h3 className="text-lg font-bold text-gray-900 mb-4">Journey Timeline</h3>
                  <div className="space-y-4">
                    {shipment.history.map((entry, idx) => (
                      <div key={entry.id} className="flex gap-4">
                        <div className="flex flex-col items-center">
                          <div className={`w-4 h-4 rounded-full ${
                            idx === 0 ? 'bg-violet-600' : 'bg-gray-300'
                          }`} />
                          {idx < shipment.history.length - 1 && (
                            <div className="w-0.5 flex-1 bg-gray-300 mt-2" style={{ minHeight: '40px' }} />
                          )}
                        </div>
                        <div className="flex-1 pb-4">
                          <p className="text-sm font-bold text-gray-900">{entry.action.toUpperCase()}</p>
                          <p className="text-sm text-gray-600 mt-1">{entry.description}</p>
                          {entry.location && (
                            <p className="text-xs text-gray-500 mt-2">📍 {entry.location}</p>
                          )}
                          <p className="text-xs text-gray-400 mt-1">
                            {new Date(entry.createdAt).toLocaleString()}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
