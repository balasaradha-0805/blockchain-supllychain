import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { ShipmentCard } from './ShipmentCard';
import { AlertPanel } from './AlertPanel';
import { BlockchainStatus } from './BlockchainStatus';
import { ShipmentWithDetails, IoTReading, Alert as AlertType} from '../types';
import { mockShipments, mockProducts, mockUsers, mockIoTReadings, mockAlerts, mockBlockchainTransactions, mockShipmentHistory } from '../services/mockData';
import { iotService } from '../services/iotService';
import { blockchainService } from '../services/blockchainService';
import { Package, TrendingUp, AlertTriangle, CheckCircle, LogOut } from 'lucide-react';

export const Dashboard: React.FC = () => {
  const { user, logout } = useAuth();
  const [shipments, setShipments] = useState<ShipmentWithDetails[]>([]);
  const [alerts, setAlerts] = useState<AlertType[]>(mockAlerts);
  const [iotReadings, setIoTReadings] = useState<IoTReading[]>(mockIoTReadings);

  useEffect(() => {
    const enrichedShipments: ShipmentWithDetails[] = mockShipments.map(shipment => {
      const product = mockProducts.find(p => p.id === shipment.productId)!;
      const currentOwner = mockUsers.find(u => u.id === shipment.currentOwnerId)!;
      const latestReading = iotReadings.find(r => r.shipmentId === shipment.id);
      const shipmentAlerts = alerts.filter(a => a.shipmentId === shipment.id);
      const transactions = mockBlockchainTransactions.filter(t => t.shipmentId === shipment.id);
      const history = mockShipmentHistory.filter(h => h.shipmentId === shipment.id);

      return {
        ...shipment,
        product,
        currentOwner,
        latestReading,
        alerts: shipmentAlerts,
        transactions,
        history
      };
    });

    setShipments(enrichedShipments);

    enrichedShipments.forEach(shipment => {
      if (shipment.status === 'in_transit' || shipment.status === 'alert') {
        const baseTemp = shipment.latestReading?.temperature ||
          (shipment.product.optimalTempMin + shipment.product.optimalTempMax) / 2;
        const baseHumidity = shipment.latestReading?.humidity ||
          (shipment.product.optimalHumidityMin + shipment.product.optimalHumidityMax) / 2;

        iotService.startMonitoring(
          shipment.id,
          shipment.product,
          baseTemp,
          baseHumidity,
          shipment.latestReading?.latitude,
          shipment.latestReading?.longitude,
          (reading) => {
            setIoTReadings(prev => [...prev.filter(r => r.id !== reading.id), reading]);

            if (
              reading.temperature < shipment.product.optimalTempMin ||
              reading.temperature > shipment.product.optimalTempMax
            ) {
              const newAlert: AlertType = {
                id: `a${Date.now()}`,
                shipmentId: shipment.id,
                alertType: 'temperature',
                severity: 'critical',
                message: `Temperature ${reading.temperature < shipment.product.optimalTempMin ? 'below' : 'exceeded'} safe range: ${reading.temperature}°C`,
                isResolved: false,
                createdAt: new Date().toISOString()
              };
              setAlerts(prev => [...prev, newAlert]);

              blockchainService.createTransaction(
                shipment.id,
                'alert',
                shipment.currentOwner.walletAddress || '0x0000',
                undefined,
                {
                  alert_type: 'temperature',
                  severity: 'critical',
                  value: reading.temperature
                }
              );
            }
          },
          8000
        );
      }
    });

    return () => {
      iotService.stopAllMonitoring();
    };
  }, []);

  const handleResolveAlert = async (alertId: string, action: string) => {
    const alert = alerts.find(a => a.id === alertId);
    if (!alert) return;

    const updatedAlert: AlertType = {
      ...alert,
      isResolved: true,
      actionTaken: action,
      resolvedAt: new Date().toISOString()
    };

    setAlerts(prev => prev.map(a => a.id === alertId ? updatedAlert : a));

    const shipment = shipments.find(s => s.id === alert.shipmentId);
    if (shipment) {
      await blockchainService.createTransaction(
        shipment.id,
        'condition_update',
        shipment.currentOwner.walletAddress || '0x0000',
        undefined,
        {
          action: 'alert_resolved',
          alert_id: alertId,
          resolution: action
        }
      );
    }
  };

  const userShipments = shipments.filter(s =>
    s.currentOwnerId === user?.id ||
    s.product.manufacturerId === user?.id
  );

  const stats = {
    total: userShipments.length,
    inTransit: userShipments.filter(s => s.status === 'in_transit').length,
    alerts: alerts.filter(a => !a.isResolved && userShipments.some(s => s.id === a.shipmentId)).length,
    delivered: userShipments.filter(s => s.status === 'delivered').length
  };

  const isOwner = user?.role === 'owner';

  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-50 via-white to-violet-50">
      <nav className="bg-violet-700 shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-3">
              <span className="text-xl font-bold text-white">
                MediTrace
              </span>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-right">
                <p className="text-sm font-medium text-white">{user?.name}</p>
                <p className="text-xs text-violet-200">{user?.role}</p>
              </div>
              <button
                onClick={logout}
                className="flex items-center gap-2 px-4 py-2 text-white hover:text-violet-200 transition-colors"
              >
                <LogOut className="w-4 h-4 text-white" />
                Logout
              </button>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Supply Chain Dashboard</h1>
          <p className="text-gray-600">Real-time monitoring and blockchain verification</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-xl p-6 shadow-lg border-2 border-violet-500 hover:shadow-xl transition-shadow">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm text-gray-600">Total Shipments</p>
              <Package className="w-5 h-5 text-violet-600" />
            </div>
            <p className="text-3xl font-bold text-gray-900">{stats.total}</p>
          </div>

          <div className="bg-white rounded-xl p-6 shadow-lg border-2 border-violet-500 hover:shadow-xl transition-shadow">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm text-gray-600">In Transit</p>
              <TrendingUp className="w-5 h-5 text-blue-600" />
            </div>
            <p className="text-3xl font-bold text-gray-900">{stats.inTransit}</p>
          </div>

          <div className="bg-white rounded-xl p-6 shadow-lg border-2 border-violet-500 hover:shadow-xl transition-shadow">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm text-gray-600">Active Alerts</p>
              <AlertTriangle className="w-5 h-5 text-red-600" />
            </div>
            <p className="text-3xl font-bold text-gray-900">{stats.alerts}</p>
          </div>

          <div className="bg-white rounded-xl p-6 shadow-lg border-2 border-violet-500 hover:shadow-xl transition-shadow">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm text-gray-600">Delivered</p>
              <CheckCircle className="w-5 h-5 text-green-600" />
            </div>
            <p className="text-3xl font-bold text-gray-900">{stats.delivered}</p>
          </div>
        </div>

        {isOwner ? (
          <div className="space-y-6">
            <div className="bg-white rounded-xl p-6 shadow-lg border-2 border-violet-500">
              <h2 className="text-xl font-bold text-gray-900 mb-4">Your Shipments</h2>
              {userShipments.length > 0 ? (
                <div className="space-y-4">
                  {userShipments.map(shipment => (
                    <ShipmentCard key={shipment.id} shipment={shipment} />
                  ))}
                </div>
              ) : (
                <p className="text-gray-500 text-center py-8">No shipments available</p>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="border-2 border-violet-500 rounded-xl">
                <BlockchainStatus />
              </div>
              <div className="border-2 border-violet-500 rounded-xl">
                <AlertPanel alerts={alerts.filter(a => !a.isResolved)} onResolve={handleResolveAlert} />
              </div>
            </div>
          </div>
        ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
            <div className="lg:col-span-2 space-y-6">
              <h2 className="text-xl font-bold text-gray-900 mb-4">Your Shipments</h2>
              {userShipments.map(shipment => (
                <ShipmentCard key={shipment.id} shipment={shipment} />
              ))}
            </div>

            <div className="space-y-6">
              <div className="border-2 border-violet-500 rounded-xl">
                <BlockchainStatus />
              </div>
              <div className="border-2 border-violet-500 rounded-xl">
                <AlertPanel alerts={alerts.filter(a => !a.isResolved)} onResolve={handleResolveAlert} />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};