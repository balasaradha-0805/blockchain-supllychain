import React, { useState } from 'react';
import { Alert } from '../types';
import { AlertTriangle, CheckCircle, X } from 'lucide-react';

interface AlertPanelProps {
  alerts: Alert[];
  onResolve: (alertId: string, action: string) => void;
}

export const AlertPanel: React.FC<AlertPanelProps> = ({ alerts, onResolve }) => {
  const [selectedAlert, setSelectedAlert] = useState<string | null>(null);
  const [actionText, setActionText] = useState('');

  const handleResolve = () => {
    if (selectedAlert && actionText.trim()) {
      onResolve(selectedAlert, actionText.trim());
      setSelectedAlert(null);
      setActionText('');
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-lg border border-red-100 p-6">
      <div className="flex items-center gap-2 mb-4">
        <AlertTriangle className="w-5 h-5 text-red-600" />
        <h3 className="text-lg font-bold text-gray-900">Active Alerts</h3>
        <span className="ml-auto bg-red-100 text-red-700 px-2 py-1 rounded-full text-xs font-medium">
          {alerts.length}
        </span>
      </div>

      <div className="space-y-3 max-h-96 overflow-y-auto">
        {alerts.length === 0 ? (
          <div className="text-center py-8">
            <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-3" />
            <p className="text-gray-600 text-sm">All systems normal</p>
          </div>
        ) : (
          alerts.map(alert => (
            <div
              key={alert.id}
              className={`p-4 rounded-lg border ${
                alert.severity === 'critical'
                  ? 'bg-red-50 border-red-200'
                  : 'bg-yellow-50 border-yellow-200'
              }`}
            >
              <div className="flex items-start justify-between mb-2">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className={`px-2 py-0.5 rounded text-xs font-medium ${
                      alert.severity === 'critical'
                        ? 'bg-red-200 text-red-800'
                        : 'bg-yellow-200 text-yellow-800'
                    }`}>
                      {alert.severity.toUpperCase()}
                    </span>
                    <span className="text-xs text-gray-500">
                      {alert.alertType.toUpperCase()}
                    </span>
                  </div>
                  <p className={`text-sm font-medium ${
                    alert.severity === 'critical' ? 'text-red-900' : 'text-yellow-900'
                  }`}>
                    {alert.message}
                  </p>
                  <p className="text-xs text-gray-500 mt-1">
                    {new Date(alert.createdAt).toLocaleString()}
                  </p>
                </div>
              </div>

              {selectedAlert === alert.id ? (
                <div className="mt-3 space-y-2">
                  <input
                    type="text"
                    value={actionText}
                    onChange={(e) => setActionText(e.target.value)}
                    placeholder="Describe action taken..."
                    className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-violet-500 focus:border-transparent outline-none"
                  />
                  <div className="flex gap-2">
                    <button
                      onClick={handleResolve}
                      className="flex-1 bg-green-600 text-white py-2 px-3 rounded-lg text-sm font-medium hover:bg-green-700 transition-colors"
                    >
                      Resolve
                    </button>
                    <button
                      onClick={() => {
                        setSelectedAlert(null);
                        setActionText('');
                      }}
                      className="flex-1 bg-gray-200 text-gray-700 py-2 px-3 rounded-lg text-sm font-medium hover:bg-gray-300 transition-colors"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              ) : (
                <button
                  onClick={() => setSelectedAlert(alert.id)}
                  className="mt-3 w-full bg-white text-violet-600 py-2 px-3 rounded-lg text-sm font-medium hover:bg-violet-50 transition-colors border border-violet-200"
                >
                  Take Action
                </button>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
};
