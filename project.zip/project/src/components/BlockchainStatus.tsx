import React, { useState, useEffect } from 'react';
import { blockchainService } from '../services/blockchainService';
import { Link, Activity } from 'lucide-react';

export const BlockchainStatus: React.FC = () => {
  const [status, setStatus] = useState<{ connected: boolean; latestBlock: number; networkId: string } | null>(null);

  useEffect(() => {
    const fetchStatus = async () => {
      const blockchainStatus = await blockchainService.getBlockchainStatus();
      setStatus(blockchainStatus);
    };

    fetchStatus();
    const interval = setInterval(fetchStatus, 10000);

    return () => clearInterval(interval);
  }, []);

  if (!status) {
    return (
      <div className="bg-white rounded-xl shadow-lg border border-violet-100 p-6">
        <div className="animate-pulse space-y-3">
          <div className="h-4 bg-gray-200 rounded w-3/4"></div>
          <div className="h-4 bg-gray-200 rounded w-1/2"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-lg border border-violet-100 p-6">
      <div className="flex items-center gap-2 mb-4">
        <Link className="w-5 h-5 text-violet-600" />
        <h3 className="text-lg font-bold text-gray-900">Blockchain Status</h3>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-sm text-gray-600">Connection</span>
          <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${status.connected ? 'bg-green-500' : 'bg-red-500'} animate-pulse`}></div>
            <span className={`text-sm font-medium ${status.connected ? 'text-green-700' : 'text-red-700'}`}>
              {status.connected ? 'Connected' : 'Disconnected'}
            </span>
          </div>
        </div>

        <div className="flex items-center justify-between">
          <span className="text-sm text-gray-600">Network</span>
          <span className="text-sm font-medium text-gray-900">{status.networkId}</span>
        </div>

        <div className="flex items-center justify-between">
          <span className="text-sm text-gray-600">Latest Block</span>
          <span className="text-sm font-medium text-gray-900 font-mono">
            #{status.latestBlock.toLocaleString()}
          </span>
        </div>

        <div className="pt-4 border-t border-gray-200">
          <div className="flex items-center gap-2 mb-2">
            <Activity className="w-4 h-4 text-violet-600" />
            <span className="text-xs font-medium text-gray-700">Network Activity</span>
          </div>
          <div className="flex gap-1 h-12 items-end">
            {[...Array(20)].map((_, i) => (
              <div
                key={i}
                className="flex-1 bg-gradient-to-t from-violet-600 to-violet-400 rounded-sm animate-pulse"
                style={{
                  height: `${Math.random() * 100}%`,
                  animationDelay: `${i * 0.1}s`
                }}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
