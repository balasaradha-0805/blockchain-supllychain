import React, { useState } from 'react';
import { ShipmentWithDetails } from '../types';
import { Package, MapPin, Thermometer, Droplets, AlertTriangle, Clock, ChevronDown, ChevronUp } from 'lucide-react';

interface ShipmentCardProps {
  shipment: ShipmentWithDetails;
}

export const ShipmentCard: React.FC<ShipmentCardProps> = ({ shipment }) => {
  const [expanded, setExpanded] = useState(false);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'in_transit': return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'delivered': return 'bg-green-100 text-green-700 border-green-200';
      case 'alert': return 'bg-red-100 text-red-700 border-red-200';
      case 'recalled': return 'bg-gray-100 text-gray-700 border-gray-200';
      default: return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  const isTempSafe = shipment.latestReading ?
    shipment.latestReading.temperature >= shipment.product.optimalTempMin &&
    shipment.latestReading.temperature <= shipment.product.optimalTempMax : true;

  const isHumiditySafe = shipment.latestReading ?
    shipment.latestReading.humidity >= shipment.product.optimalHumidityMin &&
    shipment.latestReading.humidity <= shipment.product.optimalHumidityMax : true;

  return (
    <div className="bg-white rounded-xl shadow-lg border-2 border-violet-500 overflow-hidden hover:shadow-xl transition-shadow">
      <div className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
              <Package className="w-6 h-6 text-violet-600" />
              <h3 className="text-xl font-bold text-gray-900">{shipment.product.name}</h3>
            </div>
            <p className="text-gray-600 text-sm mb-2">{shipment.product.description}</p>
            <div className="flex items-center gap-2">
              <span className="text-xs text-gray-500">Batch: {shipment.product.batchNumber}</span>
              <span className="text-xs text-gray-400">•</span>
              <span className="text-xs text-gray-500">QR: {shipment.qrCode}</span>
            </div>
          </div>
          <div className={`px-3 py-1 rounded-full text-xs font-medium border ${getStatusColor(shipment.status)}`}>
            {shipment.status.replace('_', ' ').toUpperCase()}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-4">
          <div className="flex items-center gap-2 text-sm">
            <MapPin className="w-4 h-4 text-gray-400" />
            <div>
              <p className="text-gray-500 text-xs">Current Location</p>
              <p className="text-gray-900 font-medium">{shipment.currentLocation}</p>
            </div>
          </div>
          <div className="flex items-center gap-2 text-sm">
            <Clock className="w-4 h-4 text-gray-400" />
            <div>
              <p className="text-gray-500 text-xs">Owner</p>
              <p className="text-gray-900 font-medium">{shipment.currentOwner.companyName}</p>
            </div>
          </div>
        </div>

        {shipment.latestReading && (
          <div className="grid grid-cols-2 gap-4 p-4 bg-gradient-to-br from-violet-50 to-white rounded-lg border border-violet-100 mb-4">
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-lg ${isTempSafe ? 'bg-green-100' : 'bg-red-100'}`}>
                <Thermometer className={`w-5 h-5 ${isTempSafe ? 'text-green-600' : 'text-red-600'}`} />
              </div>
              <div>
                <p className="text-xs text-gray-600">Temperature</p>
                <p className={`text-lg font-bold ${isTempSafe ? 'text-gray-900' : 'text-red-600'}`}>
                  {shipment.latestReading.temperature}°C
                </p>
                <p className="text-xs text-gray-500">
                  Range: {shipment.product.optimalTempMin}°C - {shipment.product.optimalTempMax}°C
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-lg ${isHumiditySafe ? 'bg-green-100' : 'bg-red-100'}`}>
                <Droplets className={`w-5 h-5 ${isHumiditySafe ? 'text-green-600' : 'text-red-600'}`} />
              </div>
              <div>
                <p className="text-xs text-gray-600">Humidity</p>
                <p className={`text-lg font-bold ${isHumiditySafe ? 'text-gray-900' : 'text-red-600'}`}>
                  {shipment.latestReading.humidity}%
                </p>
                <p className="text-xs text-gray-500">
                  Range: {shipment.product.optimalHumidityMin}% - {shipment.product.optimalHumidityMax}%
                </p>
              </div>
            </div>
          </div>
        )}

        {shipment.alerts.length > 0 && (
          <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <AlertTriangle className="w-4 h-4 text-red-600" />
              <p className="text-sm font-medium text-red-900">
                {shipment.alerts.filter(a => !a.isResolved).length} Active Alerts
              </p>
            </div>
            {shipment.alerts.slice(0, 2).map(alert => (
              <div key={alert.id} className="text-xs text-red-700 mb-1">
                • {alert.message}
              </div>
            ))}
          </div>
        )}

        <button
          onClick={() => setExpanded(!expanded)}
          className="w-full flex items-center justify-center gap-2 py-2 text-violet-600 hover:text-violet-700 font-medium transition-colors"
        >
          {expanded ? (
            <>
              <ChevronUp className="w-4 h-4" />
              Hide Details
            </>
          ) : (
            <>
              <ChevronDown className="w-4 h-4" />
              View Full Details
            </>
          )}
        </button>
      </div>

      {expanded && (
        <div className="border-t border-violet-100 bg-gradient-to-br from-violet-50 to-white">
          <div className="p-6 space-y-6">
            <div>
              <h4 className="text-sm font-bold text-gray-900 mb-3 flex items-center gap-2">
                <Package className="w-4 h-4 text-violet-600" />
                Product Information
              </h4>
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <p className="text-gray-600">Category</p>
                  <p className="text-gray-900 font-medium">{shipment.product.category}</p>
                </div>
                <div>
                  <p className="text-gray-600">Origin</p>
                  <p className="text-gray-900 font-medium">{shipment.product.origin}</p>
                </div>
                <div>
                  <p className="text-gray-600">Manufactured</p>
                  <p className="text-gray-900 font-medium">
                    {new Date(shipment.product.manufactureDate).toLocaleDateString()}
                  </p>
                </div>
                <div>
                  <p className="text-gray-600">Expires</p>
                  <p className="text-gray-900 font-medium">
                    {new Date(shipment.product.expiryDate).toLocaleDateString()}
                  </p>
                </div>
              </div>
            </div>

            <div>
              <h4 className="text-sm font-bold text-gray-900 mb-3">Blockchain Transactions</h4>
              <div className="space-y-2">
                {shipment.transactions.map(tx => (
                  <div key={tx.id} className="p-3 bg-white rounded-lg border border-violet-100 text-xs">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-medium text-gray-900">{tx.transactionType.toUpperCase()}</span>
                      <span className="text-gray-500">Block #{tx.blockNumber}</span>
                    </div>
                    <p className="text-gray-600 font-mono truncate">{tx.transactionHash}</p>
                    <p className="text-gray-500 mt-1">
                      {new Date(tx.timestamp).toLocaleString()}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h4 className="text-sm font-bold text-gray-900 mb-3">Shipment History</h4>
              <div className="space-y-2">
                {shipment.history.map((entry, idx) => (
                  <div key={entry.id} className="flex gap-3">
                    <div className="flex flex-col items-center">
                      <div className={`w-3 h-3 rounded-full ${
                        idx === 0 ? 'bg-violet-600' : 'bg-gray-300'
                      }`} />
                      {idx < shipment.history.length - 1 && (
                        <div className="w-0.5 h-full bg-gray-300 mt-1" />
                      )}
                    </div>
                    <div className="flex-1 pb-4">
                      <p className="text-sm font-medium text-gray-900">{entry.action.toUpperCase()}</p>
                      <p className="text-xs text-gray-600">{entry.description}</p>
                      {entry.location && (
                        <p className="text-xs text-gray-500 mt-1">📍 {entry.location}</p>
                      )}
                      <p className="text-xs text-gray-400 mt-1">
                        {new Date(entry.createdAt).toLocaleString()}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};