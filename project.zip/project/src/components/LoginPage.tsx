import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { Wallet, Mail, Lock, Scan } from 'lucide-react';

interface LoginPageProps {
  onCustomerAccess: () => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onCustomerAccess }) => {
  const { login, loginWithWallet } = useAuth();
  const [loginType, setLoginType] = useState<'email' | 'wallet'>('email');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [walletAddress, setWalletAddress] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleEmailLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    const success = await login(email, password);
    setIsLoading(false);

    if (!success) {
      setError('Invalid credentials');
    }
  };

  const handleWalletLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    const success = await loginWithWallet(walletAddress);
    setIsLoading(false);

    if (!success) {
      setError('Wallet not found');
    }
  };

  return (
    <div className="min-h-screen grid md:grid-cols-2">
      {/* LEFT HALF - Violet background */}
      <div className="bg-gradient-to-br from-violet-700 to-violet-900 flex items-center justify-center p-8 text-white">
        <div className="max-w-md space-y-6 text-center md:text-left">
          <h1 className="text-5xl font-bold leading-tight">MediTrace</h1>
          <p className="text-xl opacity-90">
            Track every dose — secure, verified, and real-time.
          </p>

          <div className="flex flex-wrap gap-4 justify-center md:justify-start pt-4">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-white rounded-full"></div>
              <span>Live IoT Tracking</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-white rounded-full"></div>
              <span>Blockchain Verified</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-white rounded-full"></div>
              <span>Real-time Alerts</span>
            </div>
          </div>
        </div>
      </div>

      {/* RIGHT HALF - White background (Login Form) */}
      <div className="bg-white flex items-center justify-center p-10">
        <div className="w-full max-w-md space-y-6">
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Stakeholder Login</h2>
            <p className="text-gray-600">Access your supply chain dashboard</p>
          </div>

          {/* Login Type Tabs */}
          <div className="flex gap-2 p-1 bg-gray-100 rounded-lg">
            <button
              onClick={() => setLoginType('email')}
              className={`flex-1 flex items-center justify-center gap-2 py-2 px-4 rounded-md transition-all ${
                loginType === 'email'
                  ? 'bg-white shadow-md text-violet-600'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <Mail className="w-4 h-4" />
              Email
            </button>
            <button
              onClick={() => setLoginType('wallet')}
              className={`flex-1 flex items-center justify-center gap-2 py-2 px-4 rounded-md transition-all ${
                loginType === 'wallet'
                  ? 'bg-white shadow-md text-violet-600'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <Wallet className="w-4 h-4" />
              Wallet
            </button>
          </div>

          {/* Email Login */}
          {loginType === 'email' ? (
            <form onSubmit={handleEmailLogin} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-violet-500 focus:border-transparent outline-none transition-all"
                    placeholder="stakeholder@company.com"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Password
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-violet-500 focus:border-transparent outline-none transition-all"
                    placeholder="••••••••"
                    required
                  />
                </div>
              </div>

              {error && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
                  {error}
                </div>
              )}

              <button
                type="submit"
                disabled={isLoading}
                className="w-full bg-gradient-to-r from-violet-600 to-violet-700 text-white py-3 rounded-lg font-medium hover:from-violet-700 hover:to-violet-800 transition-all shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isLoading ? 'Logging in...' : 'Login'}
              </button>
            </form>
          ) : (
            // Wallet Login
            <form onSubmit={handleWalletLogin} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Wallet Address
                </label>
                <div className="relative">
                  <Wallet className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    value={walletAddress}
                    onChange={(e) => setWalletAddress(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-violet-500 focus:border-transparent outline-none transition-all"
                    placeholder="0x1234...5678"
                    required
                  />
                </div>
              </div>

              {error && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
                  {error}
                </div>
              )}

              <button
                type="submit"
                disabled={isLoading}
                className="w-full bg-gradient-to-r from-violet-600 to-violet-700 text-white py-3 rounded-lg font-medium hover:from-violet-700 hover:to-violet-800 transition-all shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isLoading ? 'Connecting...' : 'Connect Wallet'}
              </button>
            </form>
          )}

          {/* Divider */}
          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-gray-200"></div>
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-4 bg-white text-gray-500">or</span>
            </div>
          </div>

          {/* Customer Button */}
          <button
            onClick={onCustomerAccess}
            className="w-full flex items-center justify-center gap-2 py-3 border-2 border-violet-600 text-violet-600 rounded-lg font-medium hover:bg-violet-50 transition-all"
          >
            <Scan className="w-5 h-5" />
            Track Your Product (Customer)
          </button>

          {/* Demo Section */}
          <div className="bg-violet-50 p-4 rounded-lg border border-violet-100">
            <p className="text-sm text-violet-900 font-medium mb-2">Demo Credentials:</p>
            <p className="text-xs text-violet-700">
              Email: owner@supply.com | manufacturer@pharma.com | transport@logistics.com
              <br />
              Wallet: 0x1234...5678 | 0x2345...6789 | 0x3456...7890
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
