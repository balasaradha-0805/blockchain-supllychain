export type UserRole = 'owner' | 'manufacturer' | 'transporter' | 'retailer' | 'customer';

export interface User {
  id: string;
  email: string;
  role: UserRole;
  name: string;
  walletAddress?: string;
  companyName?: string;
}

export interface Product {
  id: string;
  name: string;
  description: string;
  category: string;
  origin: string;
  manufacturerId: string;
  batchNumber: string;
  manufactureDate: string;
  expiryDate: string;
  optimalTempMin: number;
  optimalTempMax: number;
  optimalHumidityMin: number;
  optimalHumidityMax: number;
}

export interface Shipment {
  id: string;
  productId: string;
  currentOwnerId: string;
  status: 'in_transit' | 'delivered' | 'alert' | 'recalled';
  origin: string;
  destination: string;
  currentLocation: string;
  qrCode: string;
  createdAt: string;
  updatedAt: string;
}

export interface IoTReading {
  id: string;
  shipmentId: string;
  temperature: number;
  humidity: number;
  latitude?: number;
  longitude?: number;
  recordedAt: string;
}

export interface Alert {
  id: string;
  shipmentId: string;
  alertType: 'temperature' | 'humidity' | 'location' | 'expiry';
  severity: 'warning' | 'critical';
  message: string;
  isResolved: boolean;
  actionTaken?: string;
  createdAt: string;
  resolvedAt?: string;
}

export interface BlockchainTransaction {
  id: string;
  shipmentId: string;
  transactionHash: string;
  blockNumber: number;
  transactionType: 'transfer' | 'alert' | 'condition_update';
  fromAddress: string;
  toAddress?: string;
  data: Record<string, unknown>;
  timestamp: string;
}

export interface ShipmentHistory {
  id: string;
  shipmentId: string;
  stakeholderId: string;
  action: 'created' | 'transferred' | 'delivered' | 'alerted' | 'resolved';
  description: string;
  location?: string;
  createdAt: string;
}

export interface ShipmentWithDetails extends Shipment {
  product: Product;
  currentOwner: User;
  latestReading?: IoTReading;
  alerts: Alert[];
  history: ShipmentHistory[];
  transactions: BlockchainTransaction[];
}
